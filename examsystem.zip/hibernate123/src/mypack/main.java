package mypack;
import org.hibernate.cfg.Configuration;

import com.mysql.cj.x.protobuf.MysqlxCursor.Fetch;

import org.hibernate.transaction;
import org.hibernate.SessionFactory;

public class main {

	public static void main(String[] args) {
		Configuration con= new Configuration();
	    con.configure("hibernate.cfg.xml");
		SessionFactory sf=con.buildSessionFactory();
		Session session=sf.openSession();
		Transaction tx= session.beginTransaction();
	    
		OnlineTest test=new OnlineTest(null);
		test.re_rollno= get sturollno;
		test.re_name=get.stuname;
		test.re_marks=get.marks;
	}
}

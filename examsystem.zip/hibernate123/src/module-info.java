module hibernate123 {
}